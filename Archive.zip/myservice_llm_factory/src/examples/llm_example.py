"""
Example usage of the LLM factory in a FastAPI service.
"""
import os
from fastapi import FastAPI, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from typing import Optional

from myservice.src.llm import LLMFactory

app = FastAPI(title="LLM Factory Example", description="Example of using the LLM factory in a FastAPI service")

@app.get("/")
async def root():
    return {"message": "LLM Factory Example"}

@app.post("/generate")
async def generate_text(
    prompt: str,
    provider: Optional[str] = Query(None, description="LLM provider (openai, azure, local)"),
    model: Optional[str] = Query(None, description="Model name"),
):
    """
    Generate text using the specified LLM provider and model.
    """
    try:
        # Use the factory to create the appropriate LLM
        llm = LLMFactory.create(
            provider=provider or os.environ.get("DEFAULT_LLM_PROVIDER", "openai"),
            model=model or os.environ.get("DEFAULT_LLM_MODEL", "gpt-3.5-turbo")
        )
        
        # Generate the response
        response = await llm.generate(prompt)
        
        # Return the response
        return {
            "text": response.text,
            "model": response.model,
            "usage": response.usage
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/generate/stream")
async def generate_text_stream(
    prompt: str,
    provider: Optional[str] = Query(None, description="LLM provider (openai, azure, local)"),
    model: Optional[str] = Query(None, description="Model name"),
):
    """
    Generate streaming text using the specified LLM provider and model.
    """
    try:
        # Use the factory to create the appropriate LLM
        llm = LLMFactory.create(
            provider=provider or os.environ.get("DEFAULT_LLM_PROVIDER", "openai"),
            model=model or os.environ.get("DEFAULT_LLM_MODEL", "gpt-3.5-turbo")
        )
        
        # Create a streaming response
        async def stream_generator():
            async for chunk in llm.generate_stream(prompt):
                yield f"data: {chunk}\n\n"
            yield "data: [DONE]\n\n"
        
        return StreamingResponse(
            stream_generator(),
            media_type="text/event-stream"
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
