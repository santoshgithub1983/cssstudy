from fastapi import FastAPI
import uvicorn

from myservice.src.routers import router as api_router

app = FastAPI(title="MyService API", description="Sample FastAPI Service with LLM Integration", version="0.1.0")

# Include the API router
app.include_router(api_router)

@app.get("/")
async def root():
    return {"message": "Welcome to MyService API"}

@app.get("/health")
async def health_check():
    return {"status": "healthy"}

def start():
    """Entry point for the application."""
    uvicorn.run("myservice.src.main:app", host="0.0.0.0", port=8000, reload=False)

if __name__ == "__main__":
    start()
