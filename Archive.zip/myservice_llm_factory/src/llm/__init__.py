"""
__init__.py file for the LLM module.
"""
from myservice.src.llm.interface import BaseLLM, LLMResponse, LLMFactory
from myservice.src.llm.factory import LLMFactoryImpl
from myservice.src.llm.openai_llm import OpenAILLM
from myservice.src.llm.azure_llm import AzureOpenAILLM
from myservice.src.llm.local_llm import LocalLLM

__all__ = [
    'BaseLLM',
    'LLMResponse',
    'LLMFactory',
    'LLMFactoryImpl',
    'OpenAILLM',
    'AzureOpenAILLM',
    'LocalLLM',
]
