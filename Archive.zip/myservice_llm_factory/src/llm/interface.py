"""
LLM interface module for the FastAPI service.
This module defines the abstract interfaces for different LLM providers.
"""
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Union


class LLMResponse:
    """Class representing a response from an LLM."""
    
    def __init__(self, text: str, model: str, usage: Dict[str, int] = None):
        """
        Initialize an LLM response.
        
        Args:
            text: The generated text response
            model: The model that generated the response
            usage: Optional dictionary containing token usage information
        """
        self.text = text
        self.model = model
        self.usage = usage or {}
    
    def __str__(self) -> str:
        return self.text


class BaseLLM(ABC):
    """Abstract base class for all LLM implementations."""
    
    @abstractmethod
    async def generate(self, prompt: str, **kwargs) -> LLMResponse:
        """
        Generate a response from the LLM based on the prompt.
        
        Args:
            prompt: The input prompt to send to the LLM
            **kwargs: Additional model-specific parameters
            
        Returns:
            LLMResponse: The response from the LLM
        """
        pass
    
    @abstractmethod
    async def generate_stream(self, prompt: str, **kwargs) -> AsyncGenerator[str, None]:
        """
        Generate a streaming response from the LLM.
        
        Args:
            prompt: The input prompt to send to the LLM
            **kwargs: Additional model-specific parameters
            
        Returns:
            AsyncGenerator: An async generator yielding response chunks
        """
        pass
    
    @property
    @abstractmethod
    def model_name(self) -> str:
        """Get the name of the model being used."""
        pass


class LLMFactory:
    """Factory class for creating LLM instances."""
    
    @staticmethod
    def create(provider: str, model: str, **kwargs) -> BaseLLM:
        """
        Create an LLM instance based on the specified provider and model.
        
        Args:
            provider: The LLM provider (e.g., "openai", "azure", "local")
            model: The model name to use
            **kwargs: Additional provider-specific parameters
            
        Returns:
            BaseLLM: An instance of a concrete LLM implementation
            
        Raises:
            ValueError: If the provider is not supported
        """
        # This will be implemented in the factory implementation
        pass
