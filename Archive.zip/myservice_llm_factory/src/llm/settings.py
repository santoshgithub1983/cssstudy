"""
Configuration settings for the LLM factory.
"""
import os
from pydantic_settings import BaseSettings
from typing import Dict, Optional

class LLMSettings(BaseSettings):
    """Settings for the LLM factory."""
    
    # OpenAI settings
    OPENAI_API_KEY: Optional[str] = None
    
    # Azure OpenAI settings
    AZURE_OPENAI_API_KEY: Optional[str] = None
    AZURE_OPENAI_ENDPOINT: Optional[str] = None
    AZURE_OPENAI_API_VERSION: str = "2023-05-15"
    AZURE_DEPLOYMENT_MAP: Dict[str, str] = {}
    
    # Local model settings
    LOCAL_MODEL_PATH: Optional[str] = None
    
    # Default model selection
    DEFAULT_LLM_PROVIDER: str = "openai"
    DEFAULT_LLM_MODEL: str = "gpt-3.5-turbo"
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True

# Create a global settings instance
settings = LLMSettings()
