"""
LLM Factory implementation for selecting and creating LLM instances.
"""
import os
from typing import Dict, Optional, Type, Union
import logging

from myservice.src.llm.interface import BaseLLM, LLMFactory
from myservice.src.llm.openai_llm import OpenAILLM
from myservice.src.llm.azure_llm import AzureOpenAILLM
from myservice.src.llm.local_llm import LocalLLM

logger = logging.getLogger(__name__)

class LLMFactoryImpl:
    """Implementation of the LLM Factory."""
    
    # Provider enum values
    OPENAI = "openai"
    AZURE = "azure"
    LOCAL = "local"
    
    # Default provider and model
    DEFAULT_PROVIDER = OPENAI
    DEFAULT_MODEL = "gpt-3.5-turbo"
    
    # Mapping of provider names to their implementation classes
    _PROVIDER_MAP: Dict[str, Type[BaseLLM]] = {
        OPENAI: OpenAILLM,
        AZURE: AzureOpenAILLM,
        LOCAL: LocalLLM,
    }
    
    @classmethod
    def create(cls, 
               provider: Optional[str] = None, 
               model: Optional[str] = None, 
               **kwargs) -> BaseLLM:
        """
        Create an LLM instance based on the specified provider and model.
        
        Args:
            provider: The LLM provider (e.g., "openai", "azure", "local")
            model: The model name to use
            **kwargs: Additional provider-specific parameters
            
        Returns:
            BaseLLM: An instance of a concrete LLM implementation
            
        Raises:
            ValueError: If the provider is not supported
        """
        # Use default provider if not specified
        provider = provider or os.environ.get("DEFAULT_LLM_PROVIDER", cls.DEFAULT_PROVIDER)
        
        # Use default model if not specified
        model = model or os.environ.get("DEFAULT_LLM_MODEL", cls.DEFAULT_MODEL)
        
        logger.info(f"Creating LLM with provider={provider}, model={model}")
        
        # Get the LLM implementation class for the provider
        llm_class = cls._PROVIDER_MAP.get(provider.lower())
        if not llm_class:
            raise ValueError(f"Unsupported LLM provider: {provider}")
        
        # Create provider-specific parameters
        if provider.lower() == cls.OPENAI:
            return llm_class(model=model, **kwargs)
        
        elif provider.lower() == cls.AZURE:
            # For Azure, we need to map the model name to a deployment name
            # In a real implementation, this might come from configuration
            deployment_name = kwargs.pop("deployment_name", model)
            return llm_class(deployment_name=deployment_name, model=model, **kwargs)
        
        elif provider.lower() == cls.LOCAL:
            return llm_class(model_name=model, **kwargs)
        
        else:
            # This should never happen due to the check above
            raise ValueError(f"Unsupported LLM provider: {provider}")

# Update the factory function in the interface module to use this implementation
LLMFactory.create = LLMFactoryImpl.create
