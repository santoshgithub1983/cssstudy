"""
OpenAI LLM provider implementation.
"""
import os
from typing import AsyncGenerator, Dict, Optional, Any
import openai
from openai import AsyncOpenAI

from myservice.src.llm.interface import BaseLLM, LLMResponse


class OpenAILLM(BaseLLM):
    """Implementation of BaseLLM for OpenAI."""
    
    def __init__(
        self, 
        model: str = "gpt-3.5-turbo", 
        api_key: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs
    ):
        """
        Initialize the OpenAI LLM.
        
        Args:
            model: The OpenAI model to use
            api_key: OpenAI API key (defaults to OPENAI_API_KEY env var)
            temperature: Controls randomness (0-1)
            max_tokens: Maximum tokens to generate
            **kwargs: Additional parameters to pass to OpenAI
        """
        self._model = model
        self._api_key = api_key or os.environ.get("OPENAI_API_KEY")
        if not self._api_key:
            raise ValueError("OpenAI API key is required")
        
        self._temperature = temperature
        self._max_tokens = max_tokens
        self._additional_kwargs = kwargs
        self._client = AsyncOpenAI(api_key=self._api_key)
    
    @property
    def model_name(self) -> str:
        """Get the name of the model being used."""
        return self._model
    
    async def generate(self, prompt: str, **kwargs) -> LLMResponse:
        """
        Generate a response from OpenAI based on the prompt.
        
        Args:
            prompt: The input prompt to send to OpenAI
            **kwargs: Additional parameters to override defaults
            
        Returns:
            LLMResponse: The response from OpenAI
        """
        params = self._prepare_params(prompt, **kwargs)
        
        response = await self._client.chat.completions.create(**params)
        
        usage = None
        if hasattr(response, 'usage') and response.usage:
            usage = {
                'prompt_tokens': response.usage.prompt_tokens,
                'completion_tokens': response.usage.completion_tokens,
                'total_tokens': response.usage.total_tokens
            }
        
        return LLMResponse(
            text=response.choices[0].message.content,
            model=self._model,
            usage=usage
        )
    
    async def generate_stream(self, prompt: str, **kwargs) -> AsyncGenerator[str, None]:
        """
        Generate a streaming response from OpenAI.
        
        Args:
            prompt: The input prompt to send to OpenAI
            **kwargs: Additional parameters to override defaults
            
        Yields:
            String chunks of the generated response
        """
        params = self._prepare_params(prompt, stream=True, **kwargs)
        
        async for chunk in await self._client.chat.completions.create(**params):
            if chunk.choices and chunk.choices[0].delta.content:
                yield chunk.choices[0].delta.content
    
    def _prepare_params(self, prompt: str, **kwargs) -> Dict[str, Any]:
        """Prepare parameters for the OpenAI API call."""
        messages = [{"role": "user", "content": prompt}]
        
        # Start with default parameters
        params = {
            "model": self._model,
            "messages": messages,
            "temperature": self._temperature,
        }
        
        # Add max_tokens if specified
        if self._max_tokens:
            params["max_tokens"] = self._max_tokens
            
        # Add any additional kwargs from initialization
        params.update(self._additional_kwargs)
        
        # Override with any kwargs provided to this specific call
        params.update(kwargs)
        
        return params
