"""
Azure OpenAI LLM provider implementation.
"""
import os
from typing import AsyncGenerator, Dict, Optional, Any
import openai
from openai import AsyncAzureOpenAI

from myservice.src.llm.interface import BaseLLM, LLMResponse


class AzureOpenAILLM(BaseLLM):
    """Implementation of BaseLLM for Azure OpenAI."""
    
    def __init__(
        self, 
        deployment_name: str,
        model: str = "gpt-35-turbo",
        api_key: Optional[str] = None,
        endpoint: Optional[str] = None,
        api_version: str = "2023-05-15",
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs
    ):
        """
        Initialize the Azure OpenAI LLM.
        
        Args:
            deployment_name: The Azure OpenAI deployment name
            model: The model name for reference
            api_key: Azure OpenAI API key (defaults to AZURE_OPENAI_API_KEY env var)
            endpoint: Azure OpenAI endpoint (defaults to AZURE_OPENAI_ENDPOINT env var)
            api_version: Azure OpenAI API version
            temperature: Controls randomness (0-1)
            max_tokens: Maximum tokens to generate
            **kwargs: Additional parameters to pass to Azure OpenAI
        """
        self._deployment_name = deployment_name
        self._model = model
        self._api_key = api_key or os.environ.get("AZURE_OPENAI_API_KEY")
        self._endpoint = endpoint or os.environ.get("AZURE_OPENAI_ENDPOINT")
        
        if not self._api_key:
            raise ValueError("Azure OpenAI API key is required")
        if not self._endpoint:
            raise ValueError("Azure OpenAI endpoint is required")
        
        self._api_version = api_version
        self._temperature = temperature
        self._max_tokens = max_tokens
        self._additional_kwargs = kwargs
        
        self._client = AsyncAzureOpenAI(
            api_key=self._api_key,
            azure_endpoint=self._endpoint,
            api_version=self._api_version
        )
    
    @property
    def model_name(self) -> str:
        """Get the name of the model being used."""
        return self._model
    
    async def generate(self, prompt: str, **kwargs) -> LLMResponse:
        """
        Generate a response from Azure OpenAI based on the prompt.
        
        Args:
            prompt: The input prompt to send to Azure OpenAI
            **kwargs: Additional parameters to override defaults
            
        Returns:
            LLMResponse: The response from Azure OpenAI
        """
        params = self._prepare_params(prompt, **kwargs)
        
        response = await self._client.chat.completions.create(**params)
        
        usage = None
        if hasattr(response, 'usage') and response.usage:
            usage = {
                'prompt_tokens': response.usage.prompt_tokens,
                'completion_tokens': response.usage.completion_tokens,
                'total_tokens': response.usage.total_tokens
            }
        
        return LLMResponse(
            text=response.choices[0].message.content,
            model=self._model,
            usage=usage
        )
    
    async def generate_stream(self, prompt: str, **kwargs) -> AsyncGenerator[str, None]:
        """
        Generate a streaming response from Azure OpenAI.
        
        Args:
            prompt: The input prompt to send to Azure OpenAI
            **kwargs: Additional parameters to override defaults
            
        Yields:
            String chunks of the generated response
        """
        params = self._prepare_params(prompt, stream=True, **kwargs)
        
        async for chunk in await self._client.chat.completions.create(**params):
            if chunk.choices and chunk.choices[0].delta.content:
                yield chunk.choices[0].delta.content
    
    def _prepare_params(self, prompt: str, **kwargs) -> Dict[str, Any]:
        """Prepare parameters for the Azure OpenAI API call."""
        messages = [{"role": "user", "content": prompt}]
        
        # Start with default parameters
        params = {
            "deployment_name": self._deployment_name,
            "messages": messages,
            "temperature": self._temperature,
        }
        
        # Add max_tokens if specified
        if self._max_tokens:
            params["max_tokens"] = self._max_tokens
            
        # Add any additional kwargs from initialization
        params.update(self._additional_kwargs)
        
        # Override with any kwargs provided to this specific call
        params.update(kwargs)
        
        return params
