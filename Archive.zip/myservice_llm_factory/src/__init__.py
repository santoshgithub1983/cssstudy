"""
MyService src package initialization.
"""
