"""
Router initialization file.
"""
from fastapi import APIRouter
from myservice.src.routers.llm_router import router as llm_router

# Create a main router that includes all sub-routers
router = APIRouter()

# Include the LLM router
router.include_router(llm_router)

# Export the router
__all__ = ["router"]
