"""
Router for LLM-related endpoints.
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from typing import Optional, Dict, Any

from myservice.src.llm import LLMFactory, LLMResponse
from myservice.src.llm.settings import settings

router = APIRouter(prefix="/llm", tags=["llm"])

@router.post("/generate")
async def generate_text(
    prompt: str,
    provider: Optional[str] = Query(None, description="LLM provider (openai, azure, local)"),
    model: Optional[str] = Query(None, description="Model name"),
    temperature: Optional[float] = Query(0.7, description="Temperature (0-1)"),
    max_tokens: Optional[int] = Query(None, description="Maximum tokens to generate"),
):
    """
    Generate text using the specified LLM provider and model.
    """
    try:
        # Use the factory to create the appropriate LLM
        llm = LLMFactory.create(
            provider=provider or settings.DEFAULT_LLM_PROVIDER,
            model=model or settings.DEFAULT_LLM_MODEL,
            temperature=temperature,
            max_tokens=max_tokens
        )
        
        # Generate the response
        response: LLMResponse = await llm.generate(prompt)
        
        # Return the response
        return {
            "text": response.text,
            "model": response.model,
            "usage": response.usage
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/generate/stream")
async def generate_text_stream(
    prompt: str,
    provider: Optional[str] = Query(None, description="LLM provider (openai, azure, local)"),
    model: Optional[str] = Query(None, description="Model name"),
    temperature: Optional[float] = Query(0.7, description="Temperature (0-1)"),
    max_tokens: Optional[int] = Query(None, description="Maximum tokens to generate"),
):
    """
    Generate streaming text using the specified LLM provider and model.
    """
    try:
        # Use the factory to create the appropriate LLM
        llm = LLMFactory.create(
            provider=provider or settings.DEFAULT_LLM_PROVIDER,
            model=model or settings.DEFAULT_LLM_MODEL,
            temperature=temperature,
            max_tokens=max_tokens
        )
        
        # Create a streaming response
        async def stream_generator():
            async for chunk in llm.generate_stream(prompt):
                yield f"data: {chunk}\n\n"
            yield "data: [DONE]\n\n"
        
        return StreamingResponse(
            stream_generator(),
            media_type="text/event-stream"
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/models")
async def list_available_models():
    """
    List available LLM providers and models.
    """
    return {
        "providers": {
            "openai": ["gpt-4", "gpt-4-turbo", "gpt-3.5-turbo"],
            "azure": ["azure-gpt-4", "azure-gpt-35-turbo"],
            "local": ["llama", "mistral"]
        },
        "default_provider": settings.DEFAULT_LLM_PROVIDER,
        "default_model": settings.DEFAULT_LLM_MODEL
    }
