"""
Test script for the LLM integration.
"""
import asyncio
import os
import sys
from dotenv import load_dotenv

# Add the project root to the Python path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

# Load environment variables from .env file
load_dotenv()

from myservice.src.llm import LLMFactory

async def test_openai_llm():
    """Test the OpenAI LLM provider."""
    print("\n=== Testing OpenAI LLM ===")
    
    # Check if OpenAI API key is available
    if not os.environ.get("OPENAI_API_KEY"):
        print("Skipping OpenAI test: No API key available")
        return
    
    try:
        # Create an OpenAI LLM
        llm = LLMFactory.create(provider="openai", model="gpt-3.5-turbo")
        
        # Test generation
        prompt = "What is the capital of France?"
        print(f"Prompt: {prompt}")
        
        response = await llm.generate(prompt)
        print(f"Response: {response.text}")
        print(f"Model: {response.model}")
        print(f"Usage: {response.usage}")
        
        # Test streaming
        print("\nStreaming response:")
        async for chunk in llm.generate_stream(prompt):
            print(chunk, end="", flush=True)
        print("\n")
        
    except Exception as e:
        print(f"Error testing OpenAI LLM: {e}")

async def test_azure_llm():
    """Test the Azure OpenAI LLM provider."""
    print("\n=== Testing Azure OpenAI LLM ===")
    
    # Check if Azure OpenAI API key and endpoint are available
    if not (os.environ.get("AZURE_OPENAI_API_KEY") and os.environ.get("AZURE_OPENAI_ENDPOINT")):
        print("Skipping Azure OpenAI test: No API key or endpoint available")
        return
    
    try:
        # Create an Azure OpenAI LLM
        llm = LLMFactory.create(
            provider="azure", 
            model="azure-gpt-35-turbo",
            deployment_name="your-deployment-name"  # Replace with actual deployment name
        )
        
        # Test generation
        prompt = "What is the capital of Germany?"
        print(f"Prompt: {prompt}")
        
        response = await llm.generate(prompt)
        print(f"Response: {response.text}")
        print(f"Model: {response.model}")
        print(f"Usage: {response.usage}")
        
    except Exception as e:
        print(f"Error testing Azure OpenAI LLM: {e}")

async def test_local_llm():
    """Test the Local LLM provider."""
    print("\n=== Testing Local LLM ===")
    
    # Check if local model path is available
    if not os.environ.get("LOCAL_MODEL_PATH"):
        print("Skipping Local LLM test: No model path available")
        return
    
    try:
        # Create a Local LLM
        llm = LLMFactory.create(provider="local", model="llama")
        
        # Test generation
        prompt = "What is the capital of Italy?"
        print(f"Prompt: {prompt}")
        
        response = await llm.generate(prompt)
        print(f"Response: {response.text}")
        print(f"Model: {response.model}")
        print(f"Usage: {response.usage}")
        
    except Exception as e:
        print(f"Error testing Local LLM: {e}")

async def main():
    """Run all tests."""
    print("Testing LLM integration...")
    
    await test_openai_llm()
    await test_azure_llm()
    await test_local_llm()
    
    print("\nAll tests completed.")

if __name__ == "__main__":
    asyncio.run(main())
