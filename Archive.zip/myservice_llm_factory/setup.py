from setuptools import setup, find_packages

setup(
    name="myservice",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "fastapi>=0.68.0",
        "uvicorn>=0.15.0",
        "pydantic>=1.8.2",
    ],
    entry_points={
        "console_scripts": [
            "myservice=myservice.src.main:start",
        ],
    },
    python_requires=">=3.7",
    description="Sample FastAPI Service",
    author="User",
    author_email="user@example.com",
)
