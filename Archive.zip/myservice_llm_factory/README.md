# MyService

A sample FastAPI service packaged as a Python wheel.

## Description

This project demonstrates how to package a FastAPI application as a Python wheel and deploy it using Docker.

## Features

- FastAPI web framework
- Packaged as a Python wheel
- Docker deployment
- Entry point for starting the uvicorn server

## Installation

```bash
pip install myservice
```

## Usage

After installation, you can run the service using:

```bash
myservice
```

Or import and use in your Python code:

```python
from myservice.src.main import app
```

## Docker

The service can also be run using Docker:

```bash
docker run -p 8000:8000 myservice
```

## License

MIT
