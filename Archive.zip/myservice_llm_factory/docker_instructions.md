# Docker Build and Run Instructions

## Prerequisites
- Docker installed on your system
- The project files including the built wheel package

## Building the Docker Image

1. Navigate to the project root directory (where the Dockerfile is located):
```bash
cd /path/to/myservice
```

2. Build the Docker image:
```bash
docker build -t myservice:latest .
```

## Running the Docker Container

Run the container, mapping port 8000 from the container to port 8000 on your host:
```bash
docker run -p 8000:8000 myservice:latest
```

## Accessing the API

Once the container is running, you can access the API at:
- http://localhost:8000/ - Welcome endpoint
- http://localhost:8000/health - Health check endpoint
- http://localhost:8000/docs - Swagger UI documentation

## Troubleshooting

If you encounter any issues:

1. Ensure the wheel file is properly built and located in the `dist` directory
2. Check Docker logs for any errors:
```bash
docker logs <container_id>
```

3. If the container exits immediately, try running in interactive mode:
```bash
docker run -it -p 8000:8000 myservice:latest
```
