# LLM Factory Integration Documentation

## Overview

This document explains how to use the LLM factory pattern that has been integrated into your FastAPI service. The implementation allows you to select between different LLM providers (OpenAI, Azure OpenAI, or local models) at runtime.

## Directory Structure

The LLM integration has been organized as follows:

```
myservice/
└── src/
    ├── llm/
    │   ├── __init__.py        # Package exports
    │   ├── interface.py       # Base LLM interface
    │   ├── factory.py         # LLM factory implementation
    │   ├── openai_llm.py      # OpenAI implementation
    │   ├── azure_llm.py       # Azure OpenAI implementation
    │   ├── local_llm.py       # Local model implementation
    │   └── settings.py        # LLM configuration settings
    ├── routers/
    │   ├── __init__.py        # Router initialization
    │   └── llm_router.py      # LLM API endpoints
    ├── examples/
    │   └── llm_example.py     # Example usage
    └── main.py                # Main FastAPI application
```

## Configuration

1. Copy the `.env.example` file to `.env` and update with your API keys and settings:

```bash
cp .env.example .env
```

2. Edit the `.env` file to include your API keys and configuration:

```
# OpenAI settings
OPENAI_API_KEY=your_openai_api_key_here

# Azure OpenAI settings
AZURE_OPENAI_API_KEY=your_azure_openai_api_key_here
AZURE_OPENAI_ENDPOINT=https://your-resource-name.openai.azure.com/

# Local model settings
LOCAL_MODEL_PATH=/path/to/your/local/model

# Default model selection
DEFAULT_LLM_PROVIDER=openai
DEFAULT_LLM_MODEL=gpt-3.5-turbo
```

## API Endpoints

The integration adds the following endpoints to your FastAPI service:

### 1. Generate Text

```
POST /llm/generate
```

Parameters:
- `prompt` (required): The text prompt to send to the LLM
- `provider` (optional): The LLM provider to use (openai, azure, local)
- `model` (optional): The model name to use
- `temperature` (optional): Controls randomness (0-1)
- `max_tokens` (optional): Maximum tokens to generate

Example request:
```json
{
  "prompt": "What is the capital of France?",
  "provider": "openai",
  "model": "gpt-3.5-turbo"
}
```

### 2. Generate Streaming Text

```
POST /llm/generate/stream
```

Parameters: Same as `/llm/generate`

This endpoint returns a server-sent events (SSE) stream with the generated text.

### 3. List Available Models

```
GET /llm/models
```

Returns a list of available LLM providers and models.

## Using the LLM Factory in Your Code

You can use the LLM factory directly in your code as follows:

```python
from myservice.src.llm import LLMFactory

# Create an LLM instance
llm = LLMFactory.create(
    provider="openai",  # or "azure" or "local"
    model="gpt-3.5-turbo",
    temperature=0.7
)

# Generate text
response = await llm.generate("What is the capital of France?")
print(response.text)

# Generate streaming text
async for chunk in llm.generate_stream("What is the capital of France?"):
    print(chunk, end="", flush=True)
```

## Testing

A test script is provided to verify the LLM integration:

```bash
python test_llm.py
```

This script tests all configured LLM providers and reports the results.

## Extending the Factory

To add support for additional LLM providers:

1. Create a new implementation file (e.g., `new_provider_llm.py`) that extends the `BaseLLM` interface
2. Update the `LLMFactoryImpl._PROVIDER_MAP` in `factory.py` to include your new provider
3. Update the provider enum values in `factory.py`

## Example Usage

See `src/examples/llm_example.py` for a complete example of using the LLM factory in a FastAPI service.
