# Entry point to run the documentation generator
