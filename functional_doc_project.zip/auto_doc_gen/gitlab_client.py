# Handles GitLab API calls
