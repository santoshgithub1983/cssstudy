# Sends parsed code to LLM and gets summaries
