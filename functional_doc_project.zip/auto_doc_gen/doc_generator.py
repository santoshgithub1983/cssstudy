# Combines summaries into markdown documentation
