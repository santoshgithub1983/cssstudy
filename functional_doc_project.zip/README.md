# Auto Functional Doc Generator
This tool extracts and summarizes business logic from GitLab repos.