# test_server.py
import pytest
import httpx
import asyncio
import subprocess
import time
import sys
import socket

# Global variable to store the dynamically chosen port and base URL
SERVER_PORT = 0
BASE_URL = ""

def find_free_port():
    """Finds an available port on the host machine."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((	"127.0.0.1"	, 0)) # Bind to port 0 to let the OS choose a free port
        return s.getsockname()[1] # Return the chosen port number

@pytest.fixture(scope="session", autouse=True)
def start_server():
    """Starts the server.py in a subprocess on a free port for the test session."""
    global SERVER_PORT, BASE_URL
    
    SERVER_PORT = find_free_port()
    BASE_URL = f"http://127.0.0.1:{SERVER_PORT}"
    print(f"\nAttempting to start server on port {SERVER_PORT}...")
    
    # Use sys.executable to ensure the same Python interpreter is used
    # Pass the chosen port to the server script
    command = [sys.executable, "server.py", "--port", str(SERVER_PORT)]
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    # Wait a bit for the server to start up and check if it bound the port
    # A more robust check would involve trying to connect or checking logs
    time.sleep(3) 
    
    # Check if the process started correctly
    if process.poll() is not None: # Check if process terminated prematurely
        stdout, stderr = process.communicate()
        print(f"Server failed to start on port {SERVER_PORT}!")
        print("STDOUT:", stdout.decode())
        print("STDERR:", stderr.decode())
        pytest.fail(f"Server process failed to start on port {SERVER_PORT}.", pytrace=False)
    else:
        print(f"Server process started successfully on {BASE_URL}.")

    yield # Tests run here

    print(f"\nTerminating server process on port {SERVER_PORT}...")
    process.terminate()
    try:
        process.wait(timeout=5) # Wait for graceful termination
    except subprocess.TimeoutExpired:
        print("Server did not terminate gracefully, killing...")
        process.kill()
    print("Server process terminated.")

@pytest.mark.asyncio
async def test_root_endpoint():
    """Tests the root endpoint (	/	)."""
    async with httpx.AsyncClient() as client:
        response = await client.get(BASE_URL + "/")
        assert response.status_code == 200
        # Check content based on dummy server response
        assert "Dummy MCP Server Root" in response.text

@pytest.mark.asyncio
async def test_get_result_tool_endpoint():
    """Tests the /tools/get_result endpoint."""
    tool_url = BASE_URL + "/tools/get_result"
    payload_data = {"key": "test_value", "id": 123}
    
    async with httpx.AsyncClient() as client:
        # Assuming the tool expects a POST request with JSON payload
        response = await client.post(tool_url, json={"payload": payload_data})
        
        assert response.status_code == 200
        # Check content based on dummy server response
        assert "Dummy Tool Endpoint: /tools/get_result accessed" in response.text
        # If testing against a real server, you would assert the JSON response:
        # expected_response = {"status": "success", "data": f"Processed payload: {payload_data}"}
        # assert response.json() == expected_response

@pytest.mark.asyncio
async def test_add_numbers_tool_endpoint():
    """Tests the /tools/add_numbers endpoint."""
    tool_url = BASE_URL + "/tools/add_numbers"
    # Assuming arguments are passed in the JSON body, matching function signature
    payload_data = {"a": 5, "b": 10}
    
    async with httpx.AsyncClient() as client:
        response = await client.post(tool_url, json=payload_data)
        
        assert response.status_code == 200
        # Check content based on dummy server response
        assert "Dummy Tool Endpoint: /tools/add_numbers accessed" in response.text
        # If testing against a real server, you would assert the JSON response:
        # expected_response = {"sum": 15}
        # assert response.json() == expected_response

@pytest.mark.asyncio
async def test_nonexistent_tool_endpoint():
    """Tests accessing a tool endpoint that doesn	 exist."""
    tool_url = BASE_URL + "/tools/nonexistent_tool"
    async with httpx.AsyncClient() as client:
        response = await client.post(tool_url, json={})
        assert response.status_code == 404
        assert "Not Found" in response.text

