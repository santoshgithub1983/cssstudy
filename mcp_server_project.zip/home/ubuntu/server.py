# server.py
import asyncio
import uvicorn
import logging
import argparse # Added for command-line arguments
from typing import Dict, Any

# Configure basic logging
logging.basicConfig(level=logging.INFO, format=	'%(asctime)s - %(name)s - %(levelname)s - %(message)s		')
logger = logging.getLogger(__name__)

# Assuming the mcp library is installed and provides FastMCP
# If not, installation might be needed (e.g., pip install mcp-sdk)
try:
    from mcp.server.fastmcp import FastMCP
    logger.info("Successfully imported FastMCP from mcp.server.fastmcp")
except ImportError:
    logger.warning("MCP SDK (mcp.server.fastmcp) not found. Using dummy implementation.")
    # As a fallback for demonstration, create a dummy class
    class FastMCP:
        def __init__(self, name):
            logger.info(f"Dummy FastMCP server 		'{name}'		 created.")
            self.routes = []

        def tool(self, description=""): # Adjusted to accept description
            def decorator(func):
                tool_name = func.__name__
                logger.info(f"Dummy tool 		'{tool_name}'		 registered with description: 		'{description}'		.")
                # Store dummy route info if needed
                self.routes.append({"path": f"/tools/{tool_name}", "handler": func, "description": description})
                # In a real scenario, this would integrate with the ASGI app
                return func
            return decorator

        # Dummy ASGI interface
        async def __call__(self, scope, receive, send):
            path = scope.get(		'path'		, 		'/'		)
            logger.debug(f"Dummy ASGI received request for path: {path}")
            
            # Find matching route
            matched_route = None
            for route in self.routes:
                if route[		'path'		] == path:
                    matched_route = route
                    break

            if path == 		'/'		:
                response_body = b"Dummy MCP Server Root"
                status_code = 200
            elif matched_route:
                # Basic simulation of tool call - just acknowledge access
                response_body = f"Dummy Tool Endpoint: {path} accessed".encode(		'utf-8'		)
                status_code = 200
                # In a real implementation, you'd parse the request body,
                # call the matched_route['handler'], and serialize the response.
            else:
                response_body = b"Not Found"
                status_code = 404

            await send({
                		'type'		: 		'http.response.start'		,
                		'status'		: status_code,
                		'headers'		: [
                    [b'content-type', b'text/plain'], # Corrected byte literals
                ],
            })
            await send({
                		'type'		: 		'http.response.body'		,
                		'body'		: response_body,
            })
            logger.debug(f"Dummy ASGI sent response for path: {path}, status: {status_code}")


# Placeholder for the async request function mentioned in the snippet
async def make_request(method: str, endpoint: str, payload: dict, timeout: int) -> dict:
    """Placeholder for making an async request."""
    logger.info(f"Simulating request: {method} {endpoint} with payload {payload} and timeout {timeout}")
    # Simulate some async work
    await asyncio.sleep(0.1) # Reduced sleep time further
    # Simulate a response
    response = {"status": "success", "data": f"Processed payload: {payload}"}
    logger.info(f"Simulated request completed with response: {response}")
    return response

# Create an MCP server instance
logger.info("Initializing MCP Server...")
mcp = FastMCP("Demo")

# --- Tool Definitions --- 

@mcp.tool(description="Makes an asynchronous API request based on payload.")
async def get_result(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Example async tool that makes external requests."""
    logger.info(f"Tool 		'get_result'		 called with payload: {payload}")
    result = await make_request(
        method="POST",
        endpoint="/process",
        payload=payload,
        timeout=15
    )
    logger.info(f"Tool 		'get_result'		 returning: {result}")
    return result

@mcp.tool(description="Adds two numbers together.")
def add_numbers(a: int, b: int) -> Dict[str, Any]:
    """Example synchronous tool that performs a simple calculation."""
    logger.info(f"Tool 		'add_numbers'		 called with a={a}, b={b}")
    result = a + b
    response = {"sum": result}
    logger.info(f"Tool 		'add_numbers'		 returning: {response}")
    return response

# --- End Tool Definitions --- 

# Main block to run the server programmatically if the script is executed directly
if __name__ == "__main__":
    # Set up argument parser
    parser = argparse.ArgumentParser(description='Run the MCP Demo Server.')
    parser.add_argument('--port', type=int, default=8000, help='Port number to run the server on.')
    args = parser.parse_args()

    logger.info(f"Script executed directly. Attempting to start MCP server on port {args.port}...")
    try:
        # Configure Uvicorn to run the MCP application (mcp instance)
        config = uvicorn.Config(
            app=mcp,              # The ASGI app instance
            host="0.0.0.0",       # Listen on all available network interfaces
            port=args.port,       # Use port from command-line argument
            log_level="info",     # Uvicorn's logging level
            # reload=False        # Disable reload for programmatic start
        )
        server = uvicorn.Server(config)

        logger.info(f"Starting Uvicorn server on http://{config.host}:{config.port}")
        # Run the server using asyncio
        asyncio.run(server.serve())

    except ImportError as e:
        logger.error(f"ImportError occurred: {e}. Please ensure all dependencies (like uvicorn) are installed.")
    except SystemExit:
        logger.info("Server startup interrupted (likely by tests or manual stop).") # Handle SystemExit from server.serve()
    except Exception as e:
        # Log specific error if port is already in use
        if isinstance(e, OSError) and e.errno == 98: # Errno 98: Address already in use
             logger.error(f"Failed to start server: Port {args.port} is already in use.")
        else:
             logger.error(f"Failed to start server due to an unexpected error: {e}", exc_info=True)

else:
    logger.info("Script imported as a module, not starting server automatically.")

