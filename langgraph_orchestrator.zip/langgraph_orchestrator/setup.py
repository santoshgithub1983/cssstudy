from setuptools import setup, find_packages

setup(
    name="langgraph_orchestrator",
    version="0.1.0",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    install_requires=[
        "fastapi>=0.104.0",
        "uvicorn>=0.23.2",
        "pydantic>=2.4.2",
        "langgraph>=0.0.19",
        "python-dotenv>=1.0.0",
        "typing-extensions>=4.8.0",
    ],
    python_requires=">=3.9",
    description="LangGraph Orchestrator with FastAPI integration",
    author="Manus AI",
)
