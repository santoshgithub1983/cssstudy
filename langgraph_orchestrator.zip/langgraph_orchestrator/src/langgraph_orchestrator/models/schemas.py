from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional

class InputItem(BaseModel):
    """Model for a single input item in the workflow."""
    id: str = Field(..., description="Unique identifier for the item")
    content: str = Field(..., description="Content to be processed")
    classification: str = Field(..., description="Classification value used for routing")
    metadata: Optional[Dict[str, Any]] = Field(default=None, description="Additional metadata")

class BatchInput(BaseModel):
    """Model for batch input containing multiple items."""
    items: List[InputItem] = Field(..., description="List of items to process")

class ProcessedItem(BaseModel):
    """Model for a processed item in the workflow."""
    id: str = Field(..., description="Unique identifier for the item")
    content: str = Field(..., description="Original content")
    classification: str = Field(..., description="Classification value used for routing")
    processed_content: str = Field(..., description="Processed content")
    processor: str = Field(..., description="Name of the processor that handled this item")
    metadata: Optional[Dict[str, Any]] = Field(default=None, description="Additional metadata")

class BatchOutput(BaseModel):
    """Model for batch output containing processed items."""
    items: List[ProcessedItem] = Field(..., description="List of processed items")
