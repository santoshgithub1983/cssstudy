"""
This module provides a simple test client for the LangGraph orchestrator API.
"""
import requests
import json
from langgraph_orchestrator.utils import create_test_data

def test_orchestrator_api():
    """
    Test the orchestrator API by sending a request with sample data.
    
    Returns:
        dict: The API response
    """
    # API endpoint
    url = "http://localhost:8000/process"
    
    # Prepare test data
    test_data = {
        "items": create_test_data()
    }
    
    # Send request
    try:
        response = requests.post(url, json=test_data)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error testing API: {e}")
        return None

if __name__ == "__main__":
    print("Testing LangGraph Orchestrator API...")
    result = test_orchestrator_api()
    if result:
        print("API test successful!")
        print(json.dumps(result, indent=2))
    else:
        print("API test failed. Make sure the API server is running.")
