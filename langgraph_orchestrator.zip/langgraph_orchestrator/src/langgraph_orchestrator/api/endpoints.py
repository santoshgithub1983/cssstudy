"""
This module contains the FastAPI endpoints for the LangGraph orchestrator workflow.
"""
from fastapi import FastAPI, HTTPException
from typing import Dict, Any

from langgraph_orchestrator.models.schemas import BatchInput, BatchOutput, ProcessedItem
from langgraph_orchestrator.workflows.orchestrator import create_workflow_graph

# Create FastAPI app
app = FastAPI(
    title="LangGraph Orchestrator API",
    description="API for orchestrating workflows using LangGraph",
    version="0.1.0",
)

@app.get("/")
async def root():
    """Root endpoint that returns API information."""
    return {
        "message": "LangGraph Orchestrator API",
        "version": "0.1.0",
        "endpoints": {
            "/process": "Process a batch of items through the orchestrator workflow"
        }
    }

@app.post("/process", response_model=BatchOutput)
async def process_items(batch_input: BatchInput) -> BatchOutput:
    """
    Process a batch of items through the LangGraph orchestrator workflow.
    
    The workflow routes each item based on its classification value and
    processes it accordingly, then combines all results in the final state.
    """
    # Validate input
    if not batch_input.items:
        raise HTTPException(status_code=400, detail="No items provided for processing")
    
    # Initialize workflow state
    initial_state = {
        "input_items": batch_input.items,
        "processed_items": [],
        "current_item_index": 0,
        "status": "Starting workflow"
    }
    
    # Get the workflow graph
    workflow = create_workflow_graph()
    
    # Execute the workflow
    for event in workflow.stream(initial_state):
        # We could log events here if needed
        pass
    
    # Get the final state
    final_state = workflow.get_state()
    
    # Return the processed items
    return BatchOutput(items=final_state["processed_items"])
