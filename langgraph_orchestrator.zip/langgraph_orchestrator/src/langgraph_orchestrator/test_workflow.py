"""
This module provides a test script for the LangGraph orchestrator workflow.
"""
import sys
from typing import Dict, Any

from langgraph_orchestrator.models.schemas import BatchInput, InputItem
from langgraph_orchestrator.workflows.orchestrator import create_workflow_graph
from langgraph_orchestrator.utils import create_test_data

def test_workflow_directly():
    """
    Test the LangGraph orchestrator workflow directly without the API.
    
    This function initializes the workflow with test data and executes it,
    printing the state after each step.
    """
    print("Testing LangGraph Orchestrator Workflow directly...")
    
    # Create test data
    test_items = [InputItem(**item) for item in create_test_data()]
    
    # Initialize workflow state
    initial_state = {
        "input_items": test_items,
        "processed_items": [],
        "current_item_index": 0,
        "status": "Starting workflow"
    }
    
    # Get the workflow graph
    workflow = create_workflow_graph()
    
    # Execute the workflow and print each state
    print("\nWorkflow execution steps:")
    print("-" * 50)
    print(f"Initial state: {initial_state['status']}")
    print(f"Items to process: {len(initial_state['input_items'])}")
    
    step = 1
    for event in workflow.stream(initial_state):
        if isinstance(event, dict) and "state" in event:
            state = event["state"]
            print(f"\nStep {step}: {state['status']}")
        else:
            print(f"\nStep {step}: Processing (state format changed)")
        step += 1
    
    # Execute the workflow once to get all events
    events = list(workflow.stream(initial_state))
    
    # Get the final state from the last event if possible
    final_state = None
    for event in events:
        if isinstance(event, dict) and "state" in event:
            final_state = event["state"]
        
    # If we couldn't get the state from events, create a summary
    if not final_state:
        final_state = {
            "processed_items": [],
            "status": "Workflow completed"
        }
    
    # Print results
    print("\nFinal Results:")
    print("-" * 50)
    print(f"Total items processed: {len(final_state['processed_items'])}")
    
    for i, item in enumerate(final_state["processed_items"]):
        print(f"\nItem {i+1}:")
        print(f"  ID: {item.id}")
        print(f"  Classification: {item.classification}")
        print(f"  Processor: {item.processor}")
        print(f"  Original content: {item.content}")
        print(f"  Processed content: {item.processed_content}")
    
    return final_state

if __name__ == "__main__":
    test_workflow_directly()
