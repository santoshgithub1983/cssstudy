"""
LangGraph Orchestrator with FastAPI Integration

This module provides a multi-agent workflow system that processes a list of JSON objects
and routes them based on a classification value.
"""
import uvicorn

from langgraph_orchestrator.api.endpoints import app

if __name__ == "__main__":
    uvicorn.run("langgraph_orchestrator.main:app", host="0.0.0.0", port=8000, reload=True)
