"""
This module contains the implementation of the LangGraph orchestrator workflow.
It defines the state, nodes, and edges of the workflow graph.
"""
from typing import Dict, List, Annotated, TypedDict, Literal
from langgraph.graph import StateGraph, END
from langgraph_orchestrator.models.schemas import InputItem, ProcessedItem

# Define the state type
class WorkflowState(TypedDict):
    """State maintained during workflow execution."""
    input_items: List[InputItem]
    processed_items: List[ProcessedItem]
    current_item_index: int
    status: str

# Define processor functions for different classifications
def process_type_a(state: WorkflowState) -> Dict:
    """Process items classified as type A."""
    current_index = state["current_item_index"]
    current_item = state["input_items"][current_index]
    
    # Simulate processing for type A
    processed_item = ProcessedItem(
        id=current_item.id,
        content=current_item.content,
        classification=current_item.classification,
        processed_content=f"Type A processed: {current_item.content.upper()}",
        processor="type_a_processor",
        metadata=current_item.metadata
    )
    
    # Update state
    processed_items = state["processed_items"].copy()
    processed_items.append(processed_item)
    
    return {
        "input_items": state["input_items"],
        "processed_items": processed_items,
        "current_item_index": current_index + 1,
        "status": f"Processed item {current_index} with Type A processor"
    }

def process_type_b(state: WorkflowState) -> Dict:
    """Process items classified as type B."""
    current_index = state["current_item_index"]
    current_item = state["input_items"][current_index]
    
    # Simulate processing for type B
    processed_item = ProcessedItem(
        id=current_item.id,
        content=current_item.content,
        classification=current_item.classification,
        processed_content=f"Type B processed: {current_item.content.lower()}",
        processor="type_b_processor",
        metadata=current_item.metadata
    )
    
    # Update state
    processed_items = state["processed_items"].copy()
    processed_items.append(processed_item)
    
    return {
        "input_items": state["input_items"],
        "processed_items": processed_items,
        "current_item_index": current_index + 1,
        "status": f"Processed item {current_index} with Type B processor"
    }

def process_default(state: WorkflowState) -> Dict:
    """Process items with unknown classification."""
    current_index = state["current_item_index"]
    current_item = state["input_items"][current_index]
    
    # Simulate processing for unknown types
    processed_item = ProcessedItem(
        id=current_item.id,
        content=current_item.content,
        classification=current_item.classification,
        processed_content=f"Default processed: {current_item.content}",
        processor="default_processor",
        metadata=current_item.metadata
    )
    
    # Update state
    processed_items = state["processed_items"].copy()
    processed_items.append(processed_item)
    
    return {
        "input_items": state["input_items"],
        "processed_items": processed_items,
        "current_item_index": current_index + 1,
        "status": f"Processed item {current_index} with Default processor"
    }

# Router function to determine next node based on classification
def router(state: WorkflowState) -> Dict:
    """Route to the appropriate processor based on classification or end if all items processed."""
    # Check if all items have been processed
    if state["current_item_index"] >= len(state["input_items"]):
        return {"next": END}
    
    # Get current item's classification
    current_item = state["input_items"][state["current_item_index"]]
    classification = current_item.classification.lower()
    
    # Route based on classification
    if classification == "type_a":
        return {"next": "process_type_a"}
    elif classification == "type_b":
        return {"next": "process_type_b"}
    else:
        return {"next": "process_default"}

# Create the workflow graph
def create_workflow_graph():
    """Create and return the workflow graph."""
    # Initialize the graph
    workflow = StateGraph(WorkflowState)
    
    # Add nodes
    workflow.add_node("router", router)
    workflow.add_node("process_type_a", process_type_a)
    workflow.add_node("process_type_b", process_type_b)
    workflow.add_node("process_default", process_default)
    
    # Define conditional edges based on router's output
    workflow.add_conditional_edges(
        "router",
        lambda state: router(state)["next"],
        {
            "process_type_a": "process_type_a",
            "process_type_b": "process_type_b",
            "process_default": "process_default",
            END: END
        }
    )
    
    # Add edges from processors back to router
    workflow.add_edge("process_type_a", "router")
    workflow.add_edge("process_type_b", "router")
    workflow.add_edge("process_default", "router")
    
    # Set the entry point
    workflow.set_entry_point("router")
    
    # Compile the graph
    return workflow.compile()
