"""
This module contains utility functions for the LangGraph orchestrator.
"""
from typing import Dict, Any, List
from langgraph_orchestrator.models.schemas import InputItem, ProcessedItem

def create_test_data() -> List[Dict[str, Any]]:
    """
    Create sample test data for the orchestrator workflow.
    
    Returns:
        List[Dict[str, Any]]: A list of sample input items
    """
    return [
        {
            "id": "item1",
            "content": "This is a sample content for type A processing",
            "classification": "type_a",
            "metadata": {"source": "test", "priority": "high"}
        },
        {
            "id": "item2",
            "content": "This is a sample content for type B processing",
            "classification": "type_b",
            "metadata": {"source": "test", "priority": "medium"}
        },
        {
            "id": "item3",
            "content": "This is a sample content for default processing",
            "classification": "unknown",
            "metadata": {"source": "test", "priority": "low"}
        }
    ]
