# LangGraph Orchestrator with FastAPI

This project implements a LangGraph orchestrator workflow that processes a list of JSON objects and routes them based on classification values. The orchestrator is integrated with a FastAPI microservice to provide an API endpoint for triggering the workflow.

## Features

- Multi-agent workflow system using LangGraph
- Routing based on classification values in JSON objects
- FastAPI integration for API endpoints
- Docker containerization for easy deployment

## Project Structure

```
langgraph_orchestrator/
├── src/
│   └── langgraph_orchestrator/
│       ├── __init__.py
│       ├── main.py
│       ├── api/
│       │   └── endpoints.py
│       ├── models/
│       │   └── schemas.py
│       ├── workflows/
│       │   └── orchestrator.py
│       ├── test_workflow.py
│       ├── test_client.py
│       └── utils.py
├── requirements.txt
├── setup.py
├── Dockerfile
└── README.md
```

## Installation

### Local Development

1. Clone the repository
2. Install the package in development mode:

```bash
pip install -e .
```

### Docker Deployment

1. Build the wheel file:

```bash
python setup.py bdist_wheel
```

2. Build the Docker image:

```bash
docker build -t langgraph-orchestrator .
```

3. Run the Docker container:

```bash
docker run -p 8000:8000 langgraph-orchestrator
```

## Usage

### API Endpoints

- `GET /`: Root endpoint that returns API information
- `POST /process`: Process a batch of items through the orchestrator workflow

### Example Request

```bash
curl -X POST "http://localhost:8000/process" \
     -H "Content-Type: application/json" \
     -d '{
       "items": [
         {
           "id": "item1",
           "content": "This is a sample content for type A processing",
           "classification": "type_a",
           "metadata": {"source": "test", "priority": "high"}
         },
         {
           "id": "item2",
           "content": "This is a sample content for type B processing",
           "classification": "type_b",
           "metadata": {"source": "test", "priority": "medium"}
         },
         {
           "id": "item3",
           "content": "This is a sample content for default processing",
           "classification": "unknown",
           "metadata": {"source": "test", "priority": "low"}
         }
       ]
     }'
```

## Testing

Run the direct workflow test:

```bash
python -m src.langgraph_orchestrator.test_workflow
```

Test the API (with the server running):

```bash
python -m src.langgraph_orchestrator.test_client
```

## License

MIT
