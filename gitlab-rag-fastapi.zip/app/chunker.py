import os

def read_and_chunk(repo_dir):
    chunks = []
    for root, _, files in os.walk(repo_dir):
        for file in files:
            if file.endswith(('.py', '.js', '.java')):
                path = os.path.join(root, file)
                with open(path, 'r', errors='ignore') as f:
                    content = f.read()
                    for i in range(0, len(content), 1000):
                        chunks.append(content[i:i+1000])
    return chunks
