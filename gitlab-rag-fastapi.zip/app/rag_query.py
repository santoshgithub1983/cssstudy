from langchain.chains import RetrievalQA
from langchain.chat_models import ChatOpenAI
import os

def ask_question(query: str, index):
    retriever = index.as_retriever()
    llm = ChatOpenAI(
        openai_api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        openai_api_base=os.getenv("AZURE_OPENAI_ENDPOINT"),
        openai_api_type="azure",
        deployment_name=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
        model_name="gpt-4",
        temperature=0.3
    )
    qa = RetrievalQA.from_chain_type(llm=llm, retriever=retriever)
    return qa.run(query)
