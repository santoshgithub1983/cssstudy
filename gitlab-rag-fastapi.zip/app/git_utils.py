from git import Repo
import os

def clone_repo(git_url: str, local_dir: str):
    if os.path.exists(local_dir):
        print(f"Repo already exists at {local_dir}")
    else:
        token = os.getenv("GITLAB_TOKEN")
        if token:
            git_url = git_url.replace("https://", f"https://oauth2:{token}@")
        Repo.clone_from(git_url, local_dir)
