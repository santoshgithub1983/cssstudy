from fastapi import FastAPI
from app.routes import router
import os
from dotenv import load_dotenv

load_dotenv()

app = FastAPI(title="GitLab RAG FastAPI Service")
app.include_router(router)
