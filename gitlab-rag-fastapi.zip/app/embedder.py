from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import FAISS
from langchain.docstore.document import Document
import os

def embed_chunks(chunks, repo_id):
    docs = [Document(page_content=chunk) for chunk in chunks]
    embeddings = OpenAIEmbeddings(
        openai_api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        openai_api_base=os.getenv("AZURE_OPENAI_ENDPOINT"),
        openai_api_type="azure",
        deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")
    )
    db = FAISS.from_documents(docs, embeddings)
    db.save_local(f"vector_cache/faiss_index_{repo_id}")

def load_faiss_index(repo_id):
    embeddings = OpenAIEmbeddings(
        openai_api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        openai_api_base=os.getenv("AZURE_OPENAI_ENDPOINT"),
        openai_api_type="azure",
        deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")
    )
    return FAISS.load_local(f"vector_cache/faiss_index_{repo_id}", embeddings)
