from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List
from concurrent.futures import ThreadPoolExecutor, as_completed
from app.git_utils import clone_repo
from app.chunker import read_and_chunk
from app.embedder import embed_chunks, load_faiss_index
from app.rag_query import ask_question
import os

router = APIRouter()

class IndexRequest(BaseModel):
    repo_url: str
    repo_id: str

class BatchIndexRequest(BaseModel):
    repos: List[IndexRequest]

class QueryRequest(BaseModel):
    repo_id: str
    query: str

@router.post("/index")
def index_repo(req: IndexRequest):
    repo_path = f"cloned_repos/{req.repo_id}"
    try:
        clone_repo(req.repo_url, repo_path)
        chunks = read_and_chunk(repo_path)
        embed_chunks(chunks, req.repo_id)
        return {"message": "Repo indexed successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/index/batch")
def batch_index(req: BatchIndexRequest):
    results = []

    def process(repo):
        try:
            repo_path = f"cloned_repos/{repo.repo_id}"
            clone_repo(repo.repo_url, repo_path)
            chunks = read_and_chunk(repo_path)
            embed_chunks(chunks, repo.repo_id)
            return {"repo_id": repo.repo_id, "status": "indexed"}
        except Exception as e:
            return {"repo_id": repo.repo_id, "status": "failed", "error": str(e)}

    with ThreadPoolExecutor(max_workers=4) as executor:
        futures = [executor.submit(process, repo) for repo in req.repos]
        for future in as_completed(futures):
            results.append(future.result())

    return {"results": results}

@router.post("/query")
def query_repo(req: QueryRequest):
    try:
        index = load_faiss_index(req.repo_id)
        result = ask_question(req.query, index)
        return {"answer": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
