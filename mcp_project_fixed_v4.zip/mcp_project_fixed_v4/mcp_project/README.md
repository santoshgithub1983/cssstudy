# MCP Project with Chat UI

This project provides a modular implementation of an MCP (Model Context Protocol) server with both a command-line client and a web-based chat interface.

## Prerequisites

- Python 3.8+
- MCP library (see installation instructions below)

## Installation

1. Clone this repository or extract the provided zip file
2. Create a virtual environment (recommended):
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```
3. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```

4. **Important: Install the MCP library**
   
   The MCP (Model Context Protocol) library is required for this project to work. Please install it according to your organization's instructions. Typically, this might involve:
   
   ```
   pip install mcp-protocol  # Replace with the actual package name
   ```
   
   Or if installing from a custom source:
   
   ```
   pip install -e /path/to/mcp/library
   ```

## Project Structure

```
mcp_project/
├── .env.example            # Example environment variables (copy to .env)
├── requirements.txt        # Python dependencies
├── mcp-server.py           # Main MCP server entry point
├── mcp-client.py           # Command-line client for MCP server
├── chat_app.py             # Web-based chat interface (FastAPI)
├── src/
│   └── mcp_project/        # Main package
│       ├── __init__.py
│       ├── config.py       # Load .env configuration
│       ├── api_clients/    # Client(s) for interacting with remote APIs
│       │   ├── __init__.py
│       │   └── remote_api.py
│       ├── tools/          # MCP tool definitions
│       │   ├── __init__.py
│       │   ├── health.py
│       │   ├── config_tool.py
│       │   └── generate_result_tool.py
│       └── main.py         # MCP application setup
└── static/                 # Frontend files for chat UI
    ├── index.html
    └── style.css
```

## Configuration

1. Copy `.env.example` to `.env` in the project root directory
2. Edit `.env` to include your actual API endpoint and bearer token:
   ```
   REMOTE_API_URL=https://your-api-endpoint.com
   BEARER_TOKEN=your_secret_token_here
   ```

## Usage

### Option 1: Command-line Client

Run the MCP server and client in separate terminals:

```bash
# Terminal 1: Start the MCP server
python mcp-server.py

# Terminal 2: Start the MCP client
python mcp-client.py
```

The client provides a menu to test the available tools:
1. Health Check
2. Get Remote Config (Calls GET tool)
3. Generate Remote Result (Calls POST tool)

### Option 2: Web-based Chat Interface

```bash
# Start the chat application
python chat_app.py
```

Then open a browser and navigate to:
```
http://localhost:8000
```

In the chat interface:
1. Type commands in the format: `tool_name {json_payload}`
   - Example: `health_check {}`
   - Example: `get_remote_config {}`
   - Example: `generate_remote_result {"key": "value"}`
2. Press Enter or click Send to execute the command

## Troubleshooting

If you encounter errors like "No module named 'mcp'", ensure you have:
1. Installed the MCP library correctly
2. Activated your virtual environment
3. Installed all dependencies from requirements.txt

For other issues, check the logs in the terminal where you're running the server or chat application.
