import sys
import logging
import os

# Ensure the src directory is in the Python path
project_root = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(project_root, 'src'))

# Check for MCP library
try:
    from mcp.server.fastmcp import FastMCP
    # Import the configured MCP app instance
    from mcp_project.main import mcp_app, logger # Import logger from main
    
    if __name__ == "__main__":
        try:
            logger.info("Starting MCP stdio server (Modular Structure)")
            # The mcp_app is already created and configured in src/mcp_project/main.py
            mcp_app.run(transport="stdio")
        except ImportError as e:
            logger.error(f"Import error: {e}. Ensure 'src' is in PYTHONPATH or run from project root.")
            sys.exit(1)
        except Exception as e:
            logger.error(f"Server failed to start: {e}")
            sys.exit(1)
except ImportError:
    # Configure basic logging for the error message
    logging.basicConfig(
        level=logging.ERROR,
        format="%(asctime)s - %(levelname)s - %(message)s",
        handlers=[logging.StreamHandler(sys.stderr)]
    )
    logger = logging.getLogger("mcp-server")
    logger.error("MCP library not found. Please install the MCP library as described in README.md")
    logger.error("You may need to run: pip install mcp-protocol (or the correct package name for your MCP implementation)")
    sys.exit(1)
