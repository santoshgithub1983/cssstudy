import sys
print(f'Python version: {sys.version}')
print('Checking for MCP library...')
try:
    import mcp
    print('MCP library found.')
except ImportError as e:
    print(f'MCP library not found: {e}')
