import asyncio
import json
import logging
import os
import sys
from pathlib import Path
from typing import Optional

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger("ChatApp")

# Project paths
PROJECT_ROOT = Path(__file__).parent.resolve()
STATIC_DIR = PROJECT_ROOT / "static"
MCP_SERVER_SCRIPT = PROJECT_ROOT / "mcp-server.py"

# Check for required libraries
try:
    from fastapi import FastAPI, WebSocket, WebSocketDisconnect
    from fastapi.responses import HTMLResponse
    from fastapi.staticfiles import StaticFiles
    
    app = FastAPI()

    # Mount static files directory
    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

    # Global variable to hold the MCP server process
    mcp_process: Optional[asyncio.subprocess.Process] = None
    mcp_writer: Optional[asyncio.StreamWriter] = None
    mcp_reader: Optional[asyncio.StreamReader] = None

    # --- HTML Response --- #

    @app.get("/", response_class=HTMLResponse)
    async def get_chat_page():
        """Serves the main chat HTML page."""
        html_file_path = STATIC_DIR / "index.html"
        try:
            with open(html_file_path, "r") as f:
                return HTMLResponse(content=f.read(), status_code=200)
        except FileNotFoundError:
            logger.error(f"Frontend HTML file not found at: {html_file_path}")
            return HTMLResponse(content="<html><body><h1>Error: Frontend not found</h1></body></html>", status_code=404)
        except Exception as e:
            logger.error(f"Error reading frontend HTML: {e}")
            return HTMLResponse(content="<html><body><h1>Internal Server Error</h1></body></html>", status_code=500)

    # --- WebSocket Logic --- #

    async def read_mcp_output(websocket: WebSocket):
        """Reads output from MCP server and sends to WebSocket client."""
        global mcp_reader
        if not mcp_reader:
            logger.warning("MCP reader not available.")
            return
        try:
            while True:
                line = await mcp_reader.readline()
                if not line:
                    logger.info("MCP server stdout closed.")
                    await websocket.send_text(json.dumps({"type": "server_log", "data": "MCP server connection closed."}))
                    break # Exit if MCP process closes stdout
                decoded_line = line.decode().strip()
                logger.info(f"MCP OUT: {decoded_line}")
                # Attempt to parse as JSON (MCP tool response)
                try:
                    mcp_response = json.loads(decoded_line)
                    await websocket.send_text(json.dumps({"type": "mcp_response", "data": mcp_response}))
                except json.JSONDecodeError:
                    # If not JSON, treat as a log message from the server
                    await websocket.send_text(json.dumps({"type": "server_log", "data": decoded_line}))
        except asyncio.CancelledError:
            logger.info("MCP output reader task cancelled.")
        except Exception as e:
            logger.error(f"Error reading MCP output: {e}")
            try:
                await websocket.send_text(json.dumps({"type": "error", "data": f"Error reading MCP output: {e}"}))
            except WebSocketDisconnect:
                pass # Client already disconnected
            except Exception as ws_err:
                logger.error(f"Error sending error message via WebSocket: {ws_err}")
        finally:
            logger.info("Exiting MCP output reader.")

    @app.websocket("/ws")
    async def websocket_endpoint(websocket: WebSocket):
        """Handles WebSocket connections for the chat interface."""
        await websocket.accept()
        logger.info("WebSocket client connected.")

        global mcp_process, mcp_writer, mcp_reader
        if not mcp_process or mcp_process.returncode is not None:
            logger.warning("MCP server process not running or has exited. Cannot establish communication.")
            await websocket.send_text(json.dumps({"type": "error", "data": "MCP server is not running."}))
            await websocket.close()
            return

        if not mcp_writer or not mcp_reader:
            logger.error("MCP server streams not initialized.")
            await websocket.send_text(json.dumps({"type": "error", "data": "MCP server communication streams failed."}))
            await websocket.close()
            return

        # Start a task to read MCP output and forward to this client
        reader_task = asyncio.create_task(read_mcp_output(websocket))

        try:
            while True:
                data = await websocket.receive_text()
                logger.info(f"WebSocket IN: {data}")

                # Basic command parsing (tool_name {json_payload})
                parts = data.strip().split(" ", 1)
                tool_name = parts[0]
                payload_str = parts[1] if len(parts) > 1 else "{}"

                try:
                    payload = json.loads(payload_str)
                    if not isinstance(payload, dict):
                        raise ValueError("Payload must be a JSON object.")

                    # Construct MCP request (adjust format if MCP expects something different)
                    mcp_request = {
                        "tool_name": tool_name,
                        "body": payload
                    }
                    request_json = json.dumps(mcp_request) + "\n" # MCP might expect newline terminated JSON

                    logger.info(f"Sending to MCP: {request_json.strip()}")
                    mcp_writer.write(request_json.encode())
                    await mcp_writer.drain()

                except json.JSONDecodeError:
                    await websocket.send_text(json.dumps({"type": "error", "data": "Invalid JSON payload."}))
                except ValueError as ve:
                     await websocket.send_text(json.dumps({"type": "error", "data": str(ve)}))
                except Exception as e:
                    logger.error(f"Error processing/sending command to MCP: {e}")
                    await websocket.send_text(json.dumps({"type": "error", "data": f"Internal error: {e}"}))

        except WebSocketDisconnect:
            logger.info("WebSocket client disconnected.")
        except Exception as e:
            logger.error(f"WebSocket error: {e}")
        finally:
            logger.info("Cleaning up WebSocket connection.")
            reader_task.cancel()
            await asyncio.gather(reader_task, return_exceptions=True) # Wait for reader task to finish cleanup

    # --- Application Lifecycle (Startup/Shutdown) --- #

    async def start_mcp_server():
        """Starts the mcp-server.py script as a subprocess."""
        global mcp_process, mcp_writer, mcp_reader
        try:
            logger.info(f"Starting MCP server: {sys.executable} {MCP_SERVER_SCRIPT}")
            mcp_process = await asyncio.create_subprocess_exec(
                sys.executable, # Use the same Python interpreter
                str(MCP_SERVER_SCRIPT),
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE, # Capture stderr too
                cwd=PROJECT_ROOT # Run from project root
            )
            mcp_writer = mcp_process.stdin
            mcp_reader = mcp_process.stdout
            logger.info(f"MCP server started with PID: {mcp_process.pid}")

            # Optional: Start a task to log MCP stderr
            asyncio.create_task(log_mcp_stderr())

        except Exception as e:
            logger.error(f"Failed to start MCP server: {e}", exc_info=True)
            mcp_process = None
            mcp_writer = None
            mcp_reader = None

    async def log_mcp_stderr():
        """Logs stderr output from the MCP server process."""
        if not mcp_process or not mcp_process.stderr:
            return
        try:
            while True:
                line = await mcp_process.stderr.readline()
                if not line:
                    logger.info("MCP server stderr closed.")
                    break
                logger.warning(f"MCP STDERR: {line.decode().strip()}")
        except Exception as e:
            logger.error(f"Error reading MCP stderr: {e}")

    async def stop_mcp_server():
        """Stops the MCP server subprocess."""
        global mcp_process, mcp_writer, mcp_reader
        if mcp_process and mcp_process.returncode is None:
            logger.info(f"Stopping MCP server (PID: {mcp_process.pid})...")
            try:
                mcp_process.terminate()
                await mcp_process.wait() # Wait for termination
                logger.info("MCP server stopped.")
            except ProcessLookupError:
                 logger.warning("MCP process already terminated.")
            except Exception as e:
                logger.error(f"Error stopping MCP server: {e}")
        mcp_process = None
        mcp_writer = None
        mcp_reader = None

    @app.on_event("startup")
    async def startup_event():
        """Runs when the FastAPI application starts."""
        logger.info("FastAPI application starting up...")
        await start_mcp_server()

    @app.on_event("shutdown")
    async def shutdown_event():
        """Runs when the FastAPI application shuts down."""
        logger.info("FastAPI application shutting down...")
        await stop_mcp_server()

    # --- Main Execution (for running with uvicorn) --- #

    if __name__ == "__main__":
        import uvicorn
        logger.info("Starting Uvicorn server for chat app...")
        # Note: Uvicorn might handle startup/shutdown events differently when run programmatically vs CLI
        # Running via CLI `uvicorn chat_app:app --reload` is generally preferred for development
        uvicorn.run(app, host="0.0.0.0", port=8000)
        
except ImportError as e:
    # If required libraries are not available, show a helpful error message
    print("\n" + "="*80)
    print(f"ERROR: Required library not found: {e}")
    print("="*80)
    print("\nThis chat application requires FastAPI, Uvicorn, and the MCP library to function.")
    print("Please install the required libraries as described in README.md")
    print("\nYou may need to run: pip install -r requirements.txt")
    print("\nAfter installing the required libraries, try running this application again.")
    print("="*80 + "\n")
    sys.exit(1)
