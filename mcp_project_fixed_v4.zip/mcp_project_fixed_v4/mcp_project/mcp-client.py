import asyncio
from typing import Optional, Any
from contextlib import AsyncExitStack
import sys
import json
import logging
import os

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", # Match server log format
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger("MCPClient")

# Check for MCP library
try:
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client
    
    class MCPClient:
        def __init__(self):
            self.session: Optional[ClientSession] = None
            self.exit_stack = AsyncExitStack()

        async def connect_to_server(self, server_script_path: str):
            """Connect to an MCP server"""
            # Verify server script exists
            if not os.path.exists(server_script_path):
                logger.error(f"Server script not found: {server_script_path}")
                raise FileNotFoundError(f"Server script not found: {server_script_path}")

            # Assume server script is in the project root, adjust cwd if needed
            server_dir = os.path.dirname(os.path.abspath(server_script_path))

            server_params = StdioServerParameters(
                command=sys.executable, # Use current python interpreter
                args=[os.path.basename(server_script_path)],
                env=None, # Inherit environment (important for .env loading by server)
                cwd=server_dir # Run server from its directory
            )

            logger.info(f"Launching server: {sys.executable} {os.path.basename(server_script_path)} in {server_dir}")
            stdio_transport = await self.exit_stack.enter_async_context(stdio_client(server_params))
            self.stdio, self.write = stdio_transport
            self.session = await self.exit_stack.enter_async_context(ClientSession(self.stdio, self.write))

            await self.session.initialize()

            # List available tools
            response = await self.session.list_tools()
            tool_names = [tool.name for tool in response.tools]
            logger.info(f"Connected to MCP server. Available tools: {tool_names}")

        def _extract_text_content(self, obj):
            """
            Safely extract text from TextContent objects or any other response type.
            This function handles all possible MCP response formats.
            """
            # Direct string case
            if isinstance(obj, str):
                return obj
                
            # Handle TextContent objects directly
            if hasattr(obj, 'text') and callable(getattr(obj, 'text', None)):
                # If text is a method
                return obj.text()
            elif hasattr(obj, 'text'):
                # If text is an attribute
                return obj.text
                
            # Handle content attribute that might contain TextContent
            if hasattr(obj, 'content'):
                content = obj.content
                # Recursive call to handle nested content
                return self._extract_text_content(content)
                
            # Handle list of TextContent objects
            if isinstance(obj, list):
                result = []
                for item in obj:
                    result.append(self._extract_text_content(item))
                return "\n".join(result) if all(isinstance(x, str) for x in result) else str(result)
                    
            # Handle dict case
            if isinstance(obj, dict):
                try:
                    return json.dumps(obj, indent=2)
                except TypeError:
                    # If JSON serialization fails, convert to string
                    return str(obj)
                    
            # Fallback for any other type
            return str(obj)

        def _format_response(self, tool_name: str, result: Any) -> str:
            """Formats the MCP tool response for printing."""
            try:
                # Extract text content safely from any response type
                extracted_text = self._extract_text_content(result)
                
                # Try to parse as JSON if it looks like JSON
                if isinstance(extracted_text, str) and (
                    extracted_text.strip().startswith('{') or 
                    extracted_text.strip().startswith('[')
                ):
                    try:
                        parsed_json = json.loads(extracted_text)
                        formatted_response = json.dumps(parsed_json, indent=2)
                    except json.JSONDecodeError:
                        # Not valid JSON, use as is
                        formatted_response = extracted_text
                else:
                    # Not JSON-like, use as is
                    formatted_response = extracted_text

                logger.info(f"[MCP-SERVER Response]: {tool_name} Result:\n%s", formatted_response)
                return formatted_response
            except Exception as e:
                error_msg = f"Error formatting response for {tool_name}: {str(e)}"
                logger.error(error_msg)
                return error_msg

        async def call_health_check(self) -> str:
            """Call the health check tool."""
            try:
                logger.info("Calling tool: health_check")
                # Include the body parameter as required by the MCP server
                result = await self.session.call_tool("health_check", {"body": {}})
                return self._format_response("health_check", result)
            except Exception as e:
                error_msg = f"Error calling health_check: {str(e)}"
                logger.error(error_msg)
                return error_msg

        async def call_get_remote_config(self) -> str:
            """Call the get_remote_config tool."""
            try:
                logger.info("Calling tool: get_remote_config")
                # Include the body parameter as required by the MCP server
                result = await self.session.call_tool("get_remote_config", {"body": {}})
                return self._format_response("get_remote_config", result)
            except Exception as e:
                error_msg = f"Error calling get_remote_config: {str(e)}"
                logger.error(error_msg)
                return error_msg

        async def call_generate_remote_result(self, payload: dict[str, Any]) -> str:
            """Call the generate_remote_result tool with a payload."""
            try:
                logger.info(f"Calling tool: generate_remote_result with payload: {payload}")
                # Include the body parameter as required by the MCP server
                result = await self.session.call_tool("generate_remote_result", {"body": payload})
                return self._format_response("generate_remote_result", result)
            except Exception as e:
                error_msg = f"Error calling generate_remote_result: {str(e)}"
                logger.error(error_msg)
                return error_msg

        async def cleanup(self):
            """Clean up resources"""
            logger.info("Cleaning up client resources...")
            await self.exit_stack.aclose()
            logger.info("Client cleanup complete.")


    async def main():
        # Default server script path relative to this client script
        default_server_script = os.path.join(os.path.dirname(__file__), "mcp-server.py")

        if len(sys.argv) < 2:
            logger.warning(f"Usage: python {sys.argv[0]} <path_to_server_script>")
            logger.info(f"Defaulting to server script: {default_server_script}")
            server_script = default_server_script
        else:
            server_script = sys.argv[1]

        client = MCPClient()
        try:
            await client.connect_to_server(server_script)

            print("\nMCP Client Menu:")
            while True:
                print("\nOptions:")
                print("1. Run Health Check")
                print("2. Get Remote Config (Calls GET tool)")
                print("3. Generate Remote Result (Calls POST tool)")
                print("4. Exit")
                choice = input("Select an option: ").strip()

                if choice == "1":
                    print("\nRunning health check...")
                    result = await client.call_health_check()
                    print("\nHealth Check Response:")
                    print(result)
                elif choice == "2":
                    print("\nGetting remote config...")
                    result = await client.call_get_remote_config()
                    print("\nGet Remote Config Response:")
                    print(result)
                elif choice == "3":
                    print("\nEnter JSON payload for Generate Remote Result (e.g., {\"key\": \"value\"}):")
                    payload_str = input("> ")
                    try:
                        payload = json.loads(payload_str)
                        print("\nGenerating remote result...")
                        result = await client.call_generate_remote_result(payload)
                        print("\nGenerate Remote Result Response:")
                        print(result)
                    except json.JSONDecodeError:
                        print("⚠️ Invalid JSON payload entered.")
                    except Exception as e:
                         print(f"⚠️ An error occurred: {e}")
                elif choice == "4":
                    print("Exiting...")
                    break
                else:
                    print("⚠️ Invalid option. Please choose 1, 2, 3, or 4.")

        except FileNotFoundError:
            logger.error(f"Failed to start client: Server script {server_script} not found.")
        except Exception as e:
            logger.error("Client encountered an error: %s", str(e), exc_info=True)
        finally:
            await client.cleanup()
            print("Client shutdown complete")


    if __name__ == "__main__":
        # Ensure asyncio event loop policies are correctly set for different OS if needed
        # Example for Windows: asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
        asyncio.run(main())
        
except ImportError:
    # If MCP library is not available, show a helpful error message
    print("\n" + "="*80)
    print("ERROR: MCP library not found!")
    print("="*80)
    print("\nThis client requires the MCP (Model Context Protocol) library to function.")
    print("Please install the MCP library as described in README.md")
    print("\nYou may need to run: pip install mcp-protocol")
    print("(or the correct package name for your MCP implementation)")
    print("\nAfter installing the MCP library, try running this client again.")
    print("="*80 + "\n")
    sys.exit(1)
