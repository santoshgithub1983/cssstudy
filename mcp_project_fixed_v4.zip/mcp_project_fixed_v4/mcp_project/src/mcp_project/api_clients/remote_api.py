
import requests
import logging
from typing import Any, Optional

from ..config import REMOTE_API_URL, BEARER_TOKEN

logger = logging.getLogger(__name__)

def get_config_from_remote() -> Optional[dict[str, Any]]:
    """Calls the remote GET /api/v1/config endpoint."""
    if not REMOTE_API_URL or not BEARER_TOKEN:
        logger.error("Remote API URL or Bearer Token is not configured in .env")
        return None

    headers = {
        "Authorization": f"Bearer {BEARER_TOKEN}",
        "Accept": "application/json"
    }
    url = f"{REMOTE_API_URL}/api/v1/config"

    try:
        logger.info(f"Calling GET {url}")
        response = requests.get(url, headers=headers, timeout=30) # Added timeout
        response.raise_for_status()  # Raise an exception for bad status codes (4xx or 5xx)
        logger.info(f"Received response from {url}: Status {response.status_code}")
        return response.json()
    except requests.exceptions.RequestException as e:
        logger.error(f"Error calling remote GET config API: {e}")
        return None
    except Exception as e:
        logger.error(f"An unexpected error occurred during GET config call: {e}")
        return None

def post_generate_result_to_remote(payload: dict[str, Any]) -> Optional[dict[str, Any]]:
    """Calls the remote POST /api/v1/generateResult endpoint."""
    if not REMOTE_API_URL or not BEARER_TOKEN:
        logger.error("Remote API URL or Bearer Token is not configured in .env")
        return None

    headers = {
        "Authorization": f"Bearer {BEARER_TOKEN}",
        "Content-Type": "application/json",
        "Accept": "application/json"
    }
    url = f"{REMOTE_API_URL}/api/v1/generateResult"

    try:
        logger.info(f"Calling POST {url} with payload: {payload}")
        response = requests.post(url, headers=headers, json=payload, timeout=60) # Added timeout
        response.raise_for_status() # Raise an exception for bad status codes (4xx or 5xx)
        logger.info(f"Received response from {url}: Status {response.status_code}")
        return response.json()
    except requests.exceptions.RequestException as e:
        logger.error(f"Error calling remote POST generateResult API: {e}")
        return None
    except Exception as e:
        logger.error(f"An unexpected error occurred during POST generateResult call: {e}")
        return None

