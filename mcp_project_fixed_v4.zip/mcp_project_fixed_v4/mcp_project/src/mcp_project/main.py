import logging
import sys
from mcp.server.fastmcp import FastMCP

# Import tools
from .tools.health import health_check
from .tools.config_tool import get_remote_config
from .tools.generate_result_tool import generate_remote_result

# Configure logging (can be more sophisticated)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler(sys.stderr)]
)
logger = logging.getLogger(__name__)

def create_mcp_app() -> FastMCP:
    """Creates and configures the FastMCP application."""
    logger.info("Initializing FastMCP application")
    mcp = FastMCP("demo-server-modular") # Updated server name

    # Register tools
    logger.info("Registering tool: health_check")
    mcp.tool()(health_check)

    logger.info("Registering tool: get_remote_config")
    mcp.tool(name="get_remote_config")(get_remote_config) # Explicit name registration

    logger.info("Registering tool: generate_remote_result")
    mcp.tool(name="generate_remote_result")(generate_remote_result) # Explicit name registration

    logger.info("MCP application initialized with tools.")
    return mcp

# Create the app instance immediately when this module is imported
mcp_app = create_mcp_app()
