
from typing import Any
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

async def health_check(body: dict[str, Any]) -> dict[str, Any]:
    """Original health check tool."""
    logger.info("Health check executed")
    return {
        "status": "healthy",
        "server": "demo-server", # Consider making this dynamic or configurable
        "version": "1.0", # Consider making this dynamic or configurable
        "timestamp": datetime.now().isoformat()
    }

