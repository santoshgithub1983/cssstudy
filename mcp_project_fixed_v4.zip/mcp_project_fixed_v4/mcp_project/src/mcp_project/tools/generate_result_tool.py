
import logging
from typing import Any

from ..api_clients.remote_api import post_generate_result_to_remote

logger = logging.getLogger(__name__)

async def generate_remote_result(body: dict[str, Any]) -> dict[str, Any]:
    """MCP Tool to call the remote POST /api/v1/generateResult endpoint."""
    logger.info(f"Executing generate_remote_result tool with body: {body}")

    # The actual API call is synchronous
    # Consider async HTTP client (httpx) or thread pool for production
    result_data = post_generate_result_to_remote(payload=body)

    if result_data is None:
        logger.error("Failed to generate result via remote API.")
        # Return an error structure
        return {"error": "Failed to generate result via remote API."}

    logger.info("Successfully generated result via remote API.")
    return result_data

