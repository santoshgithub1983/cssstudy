
import logging
from typing import Any

from ..api_clients.remote_api import get_config_from_remote

logger = logging.getLogger(__name__)

async def get_remote_config(body: dict[str, Any]) -> dict[str, Any]:
    """MCP Tool to fetch configuration from the remote /api/v1/config endpoint."""
    logger.info("Executing get_remote_config tool")

    # The actual API call is synchronous, but MCP tools are async
    # In a real-world scenario with heavy I/O, consider running sync code in a thread pool
    # For simple requests.get, this might be okay, but be mindful of blocking the event loop.
    # Alternatively, use an async HTTP client like httpx.
    config_data = get_config_from_remote()

    if config_data is None:
        logger.error("Failed to retrieve config from remote API.")
        # Return an error structure or raise an exception depending on MCP error handling preferences
        return {"error": "Failed to retrieve configuration from remote API."}

    logger.info("Successfully retrieved config from remote API.")
    return config_data

