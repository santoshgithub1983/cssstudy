'''Load configuration from .env file.'''

import os
from dotenv import load_dotenv

# Load environment variables from .env file in the project root
# Assumes .env is in the parent directory of src/
project_root = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
dotenv_path = os.path.join(project_root, '.env')
load_dotenv(dotenv_path=dotenv_path)

REMOTE_API_URL = os.getenv("REMOTE_API_URL")
BEARER_TOKEN = os.getenv("BEARER_TOKEN")

if not REMOTE_API_URL:
    print("Warning: REMOTE_API_URL not found in .env file.", file=os.sys.stderr)

if not BEARER_TOKEN:
    print("Warning: BEARER_TOKEN not found in .env file.", file=os.sys.stderr)

